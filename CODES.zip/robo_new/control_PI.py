import RPi.GPIO as GPIO
import time
import socket
import json
from threading import Thread

# Set GPIO mode to BCM
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for L298N
IN1 = 17  # Right motor
IN2 = 18
IN3 = 22  # Left motor
IN4 = 23
ENA = 24  # Right PWM
ENB = 25  # Left PWM

# Set up pins
GPIO.setup([IN1, IN2, IN3, IN4, ENA, ENB], GPIO.OUT)

# Initialize PWM
pwm_right = GPIO.PWM(ENA, 1000)
pwm_left = GPIO.PWM(ENB, 1000)
pwm_right.start(0)
pwm_left.start(0)

# Motor speeds
FORWARD_SPEED = 60
BACKWARD_SPEED = 40
TURN_SPEED = 50

class MotorController:
    def __init__(self):
        self.running = True
    
    def set_motors(self, right_speed, left_speed, right_dir, left_dir):
        right_speed = min(max(right_speed, 0), 100)
        left_speed = min(max(left_speed, 0), 100)
        GPIO.output(IN1, right_dir[0])
        GPIO.output(IN2, right_dir[1])
        GPIO.output(IN3, left_dir[0])
        GPIO.output(IN4, left_dir[1])
        pwm_right.ChangeDutyCycle(right_speed)
        pwm_left.ChangeDutyCycle(left_speed)
    
    def forward(self, speed=FORWARD_SPEED):
        self.set_motors(speed, speed, (1, 0), (0, 1))
    
    def backward(self, speed=BACKWARD_SPEED):
        self.set_motors(speed, speed, (0, 1), (1, 0))
    
    def left(self, speed=TURN_SPEED):
        self.set_motors(speed, speed, (0, 1), (0, 1))
    
    def right(self, speed=TURN_SPEED):
        self.set_motors(speed, speed, (1, 0), (0, 1))  # Fixed
        #self.set_motors(speed, speed, (1, 0), (1, 0))  # Fixed
    
    def stop(self):
        self.set_motors(0, 0, (0, 0), (0, 0))
    
    def cleanup(self):
        self.running = False
        self.stop()
        pwm_right.stop()
        pwm_left.stop()
        GPIO.cleanup()

def handle_client(conn, motor):
    buffer = ""
    while motor.running:
        try:
            data = conn.recv(1024).decode()
            if not data:
                break
            buffer += data
            while '\n' in buffer:
                line, buffer = buffer.split('\n', 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    cmd = json.loads(line)
                    action = cmd.get("action")
                    speed = cmd.get("speed")
                    if action == "forward":
                        motor.forward(speed if speed else FORWARD_SPEED)
                    elif action == "backward":
                        motor.backward(speed if speed else BACKWARD_SPEED)
                    elif action == "left":
                        motor.left(speed if speed else TURN_SPEED)
                    elif action == "right":
                        motor.right(speed if speed else TURN_SPEED)
                    elif action == "stop":
                        motor.stop()
                    conn.sendall(b"ACK")
                except json.JSONDecodeError as e:
                    print(f"JSON decode error: {e}")
                    conn.sendall(b"ERR")
                except Exception as e:
                    print(f"Command error: {e}")
                    conn.sendall(b"ERR")
        except Exception as e:
            print(f"Connection error: {e}")
            break
    conn.close()

def main():
    motor = MotorController()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', 65432))
    server.listen(1)
    print("Motor server ready...")
    try:
        while motor.running:
            conn, addr = server.accept()
            print(f"Connected: {addr}")
            Thread(target=handle_client, args=(conn, motor)).start()
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        motor.cleanup()
        server.close()

if __name__ == "__main__":
    main()
