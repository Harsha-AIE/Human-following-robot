import socket
import json
import time

# Socket setup
PI_IP = "192.168.142.130"
PI_PORT = 65432

# Socket client
def send_motor_command(action, speed=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect((PI_IP, PI_PORT))
            cmd = {"action": action}
            if speed is not None:
                cmd["speed"] = speed
            s.sendall((json.dumps(cmd) + '\n').encode())
            response = s.recv(1024).decode()
            return response == "ACK"
    except Exception as e:
        print(f"Socket error: {e}")
        return False

# Square movement parameters
MOVE_DURATION = 1.7  # Seconds for each forward or turn
SPEED = 85  # Motor speed (adjust as needed)

# State machine states
FORWARD = "forward"
TURN_RIGHT = "turn_right"

def move_in_square():
    state = FORWARD
    state_start_time = time.time()
    action_count = 0  # Track number of actions (forward or turn)
    max_actions = 8   # Complete one square (4 forwards + 4 turns)
    
    print("Starting square movement...")
    
    try:
        while action_count < max_actions:
            current_time = time.time()
            elapsed = current_time - state_start_time
            
            # Execute current state
            if state == FORWARD:
                print(f"Moving forward at speed {SPEED}")
                send_motor_command("forward", SPEED)
            elif state == TURN_RIGHT:
                print(f"Turning right at speed {SPEED}")
                send_motor_command("right", SPEED)
            
            # Check if it's time to switch states
            if elapsed >= MOVE_DURATION:
                # Increment action count
                action_count += 1
                
                # Transition to next state
                if state == FORWARD:
                    state = TURN_RIGHT
                else:  # TURN_RIGHT
                    state = FORWARD
                
                # Reset timer
                state_start_time = current_time
                
                # Brief stop between states for stability
                send_motor_command("stop")
                time.sleep(0.1)  # Short pause to ensure stop command is processed
                
                # Exit if all actions are complete
                if action_count >= max_actions:
                    break
            
            # Small delay to avoid overwhelming the socket
            time.sleep(0.01)
    
    except KeyboardInterrupt:
        print("Stopping square movement...")
        send_motor_command("stop")
    finally:
        send_motor_command("stop")
        print("Robot stopped.")

if __name__ == "__main__":
    move_in_square()