import cv2
import numpy as np
import socket
import json
import time
import pyttsx3
from ultralytics import YOLO
import pandas as pd
from uuid import uuid4

# HSV for green/maroon
HSV_LOWER = np.array([17, 76, 102])
HSV_UPPER = np.array([27, 204, 230])

# Socket setup
PI_IP = "192.168.142.130"
PI_PORT = 65432

# Camera setup
STREAM_URL = 'http://192.168.142.130:8080/?action=stream'
cap = cv2.VideoCapture(STREAM_URL, cv2.CAP_FFMPEG)
if not cap.isOpened():
    print("Error: Could not open video stream")
    exit()

# Optimize for low latency
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 416)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 312)
cap.set(cv2.CAP_PROP_FPS, 30)

# Initialize YOLOv8
model = YOLO("yolov8n.pt")

# Initialize KCF tracker
tracker = None
tracker_active = False

# Initialize pyttsx3
engine = pyttsx3.init()
engine.setProperty('rate', 150)

# Metrics logging
metrics_log = []
frame_times = []
positions = []  # For jerk calculation
commands = []  # For command stability
log_file = f"metrics_{uuid4()}.csv"

# Simulated ground truth for IoU (replace with actual annotations)
ground_truth = {
    0: (150, 100, 80, 120),
    100: (160, 110, 80, 120),
    200: (155, 105, 80, 120),
}

def calculate_iou(box1, box2):
    """Calculate IoU between two bounding boxes (x, y, w, h)."""
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    
    xi1 = max(x1, x2)
    yi1 = max(y1, y2)
    xi2 = min(x1 + w1, x2 + w2)
    yi2 = min(y1 + h1, y2 + h2)
    
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    box1_area = w1 * h1
    box2_area = w2 * h2
    union_area = box1_area + box2_area - inter_area
    
    return inter_area / union_area if union_area > 0 else 0

def send_motor_command(action, speed=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect((PI_IP, PI_PORT))
            cmd = {"action": action}
            if speed is not None:
                cmd["speed"] = speed
            s.sendall((json.dumps(cmd) + '\n').encode())
            response = s.recv(1024).decode()
            print(f"Debug: Sent {cmd}, Received {response}")
            return response == "ACK"
    except Exception as e:
        print(f"Socket error: {e}")
        return False

def speak(text):
    global last_speak_time
    current_time = time.time()
    if current_time - last_speak_time >= speak_cooldown:
        try:
            engine.say(text)
            engine.runAndWait()
            last_speak_time = current_time
        except Exception as e:
            print(f"Audio error: {e}")

def smooth_bbox(new_bbox, prev_bbox, alpha=0.3):
    if not new_bbox:
        return prev_bbox
    if not prev_bbox:
        return new_bbox
    x1, y1, w1, h1 = new_bbox
    x2, y2, w2, h2 = prev_bbox
    x = int(alpha * x1 + (1 - alpha) * x2)
    y = int(alpha * y1 + (1 - alpha) * y2)
    w = int(alpha * w1 + (1 - alpha) * w2)
    h = int(alpha * h1 + (1 - alpha) * h2)
    return (x, y, w, h)

def get_latest_frame(cap, max_attempts=5):
    latest_frame = None
    for _ in range(max_attempts):
        ret, frame = cap.read()
        if ret:
            latest_frame = frame
        else:
            break
    return ret, latest_frame

# Main loop
try:
    last_time = time.time()
    frame_count = 0
    fps = 0
    no_person_time = None
    last_bbox_area = None
    rotating = False
    rotation_start = None
    last_yolo_time = 0
    yolo_interval = 0.5
    skip_counter = 0
    fps_threshold = 10
    tracking_state = False
    prev_bbox = None
    miss_count = 0
    miss_threshold = 30
    last_command = None
    frame_number = 0
    tracking_success = 0
    last_speak_time = 0
    speak_cooldown = 5

    while True:
        start_time = time.time()
        ret, frame = get_latest_frame(cap)
        if not ret:
            print("Failed to grab frame")
            time.sleep(0.01)
            continue

        # Calculate FPS
        frame_count += 1
        current_time = time.time()
        if current_time - last_time >= 1.0:
            fps = frame_count / (current_time - last_time)
            frame_count = 0
            last_time = current_time

        # Skip frames if FPS is low
        skip_counter += 1
        if fps < fps_threshold and skip_counter % 2 != 0:
            continue

        # Initialize bbox
        bbox = None
        hsv_tracked = False
        iou = 0
        distance_error = 0

        # Try KCF tracker if active
        if tracker_active:
            success, kcf_bbox = tracker.update(frame)
            if success:
                x, y, w, h = [int(v) for v in kcf_bbox]
                if x >= 0 and y >= 0 and x + w <= frame.shape[1] and y + h <= frame.shape[0]:
                    bbox = (x, y, w, h)
                    hsv_tracked = True

        # Run YOLO periodically
        yolo_bbox = None
        max_area = 0
        frame_width = frame.shape[1]
        frame_height = frame.shape[0]

        if current_time - last_yolo_time >= yolo_interval:
            results = model(frame, classes=[0], conf=0.3, verbose=False, imgsz=416)
            for result in results:
                boxes = result.boxes.xywh.cpu().numpy()
                for box in boxes:
                    x_center, y_center, w, h = box
                    area = w * h
                    if area > max_area:
                        max_area = area
                        x = int(x_center - w / 2)
                        y = int(y_center - h / 2)
                        w, h = int(w), int(h)
                        yolo_bbox = (x, y, w, h)
            last_yolo_time = current_time

        # HSV tracking if YOLO detects person
        if yolo_bbox and not bbox:
            x, y, w, h = yolo_bbox
            roi_x = max(0, x - 20)
            roi_y = max(0, y - 20)
            roi_w = min(frame_width - roi_x, w + 40)
            roi_h = min(frame_height - roi_y, h + 40)
            roi = frame[roi_y:roi_y + roi_h, roi_x:roi_x + roi_w]

            # HSV processing
            hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, HSV_LOWER, HSV_UPPER)
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.erode(mask, kernel, iterations=1)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            hsv_bbox = None
            hsv_max_area = 0

            for contour in contours:
                area = cv2.contourArea(contour)
                if area > hsv_max_area and area > 20:
                    hsv_max_area = area
                    hsv_bbox = cv2.boundingRect(contour)

            if hsv_bbox:
                hx, hy, hw, hh = hsv_bbox
                hx += roi_x
                hy += roi_y
                bbox = (hx, hy, hw, hh)
                hsv_tracked = True
                tracker = cv2.TrackerKCF_create()
                tracker.init(frame, (hx, hy, hw, hh))
                tracker_active = True
            else:
                bbox = yolo_bbox
                tracker_active = False

        # Smooth bbox
        if bbox:
            bbox = smooth_bbox(bbox, prev_bbox, alpha=0.3)
            prev_bbox = bbox
            miss_count = 0
            tracking_success += 1
            if frame_number in ground_truth:
                iou = calculate_iou(bbox, ground_truth[frame_number])
        else:
            miss_count += 1
            if miss_count <= miss_threshold and prev_bbox:
                bbox = prev_bbox
                tracker_active = False
            else:
                prev_bbox = None
                tracker_active = False

        # Process bbox
        if bbox:
            x, y, w, h = bbox
            center_x = x + w // 2
            center_y = y + h // 2
            bbox_area = w * h

            # Calculate distance error
            target_center = frame_width // 2
            distance_error = abs(center_x - target_center)

            # Store position for jerk calculation
            positions.append((center_x, center_y))

            # Draw bbox
            color = (0, 255, 0) if hsv_tracked or tracker_active else (255, 0, 0)
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 1)

            # Voice prompt
            if not tracking_state:
                speak("Following person in maroon")
                tracking_state = True

            # Reset timers
            no_person_time = None
            rotating = False
            rotation_start = None

            # Movement logic
            max_area = frame_width * frame_height
            area_ratio = bbox_area / max_area
            action = "stop"
            speed = None

            # Backward if too close
            if area_ratio > 0.5:
                print("Too close, moving backward")
                action = "backward"
                speed = 50
                send_motor_command("backward", 50)
                last_command = ("backward", 50)
                last_bbox_area = bbox_area
            else:
                # Forward speed based on distance
                if area_ratio < 0.1:
                    speed = 80
                elif area_ratio < 0.3:
                    speed = 60
                else:
                    speed = 40

                # Dynamic turning speed based on distance from center
                max_distance = frame_width // 2
                min_turn_speed = 50
                max_turn_speed = 80
                turn_speed = min_turn_speed + (max_turn_speed - min_turn_speed) * (distance_error / max_distance)
                turn_speed = min(max(turn_speed, min_turn_speed), max_turn_speed)  # Clamp

                # Direction based on position
                if center_x > frame_width * 0.6:
                    print(f"Turning right at {turn_speed:.1f}")
                    action = "right"
                    send_motor_command("right", int(turn_speed))
                    last_command = ("right", int(turn_speed))
                elif center_x < frame_width * 0.4:
                    print(f"Turning left at {turn_speed:.1f}")
                    action = "left"
                    send_motor_command("left", int(turn_speed))
                    last_command = ("left", int(turn_speed))
                else:
                    print(f"Moving forward at {speed}")
                    action = "forward"
                    send_motor_command("forward", speed)
                    last_command = ("forward", speed)

            last_bbox_area = bbox_area
            commands.append((action, speed))
        else:
            if no_person_time is None and miss_count > miss_threshold:
                no_person_time = current_time
                rotation_start = current_time
                if tracking_state:
                    speak("Searching for person in maroon")
                    tracking_state = False
                print("No person in maroon, starting rotation")
                rotating = True
                action = "right"
                speed = 30
                send_motor_command("right", 30)
                last_command = ("right", 30)
                commands.append(("right", 30))
            elif rotating and current_time - rotation_start >= 10:
                print("Finished rotation, stopping")
                action = "stop"
                send_motor_command("stop")
                last_command = ("stop", None)
                no_person_time = None
                rotating = False
                rotation_start = None
                if not tracking_state:
                    speak("Searching for person in maroon")
                commands.append(("stop", None))
            else:
                if not rotating and miss_count > miss_threshold:
                    print("No person in maroon, stopping")
                    action = "stop"
                    send_motor_command("stop")
                    last_command = ("stop", None)
                    commands.append(("stop", None))
                elif last_command:
                    action, speed = last_command
                    send_motor_command(action, speed)
                    commands.append((action, speed))
            last_bbox_area = None
            tracking_state = False

        # Calculate latency
        latency = (time.time() - start_time) * 1000  # in ms
        frame_times.append(latency)

        # Log metrics
        metrics_log.append({
            "frame": frame_number,
            "fps": fps,
            "latency_ms": latency,
            "iou": iou,
            "distance_error": distance_error,
            "tracking_success": 1 if bbox else 0,
            "center_x": center_x if bbox else 0,
            "center_y": center_y if bbox else 0
        })

        # Display metrics
        cv2.putText(frame, f"FPS: {fps:.1f}", (10, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(frame, f"IoU: {iou:.2f}", (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(frame, f"DistErr: {distance_error:.1f}", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(frame, f"Latency: {latency:.1f}ms", (10, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        cv2.putText(frame, f"State: {'Tracked' if tracking_state else 'Searching'}", (10, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

        cv2.imshow("Frame", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_number += 1

except KeyboardInterrupt:
    print("Shutting down...")
finally:
    send_motor_command("stop")
    cap.release()
    cv2.destroyAllWindows()
    engine.stop()

    # Save metrics to CSV
    metrics_df = pd.DataFrame(metrics_log)
    metrics_df.to_csv(log_file, index=False)

    # Calculate jerk
    if len(positions) > 3:
        dt = 1 / fps if fps > 0 else 0.033
        positions = np.array(positions)
        velocity = np.diff(positions, axis=0) / dt
        acceleration = np.diff(velocity, axis=0) / dt
        jerk = np.diff(acceleration, axis=0) / dt
        jerk_magnitude = np.mean(np.sqrt(jerk[:, 0]*2 + jerk[:, 1]*2))
    else:
        jerk_magnitude = 0

    # Calculate command stability
    command_changes = 0
    for i in range(1, len(commands)):
        if commands[i] != commands[i-1]:
            command_changes += 1
    command_stability = command_changes / len(commands) if commands else 0

    # Calculate tracking success rate
    tracking_success_rate = (tracking_success / frame_number) * 100 if frame_number > 0 else 0

    # Print summary
    print("\n=== Evaluation Metrics Summary ===")
    print(f"Total Frames: {frame_number}")
    print(f"Average FPS: {metrics_df['fps'].mean():.2f}")
    print(f"Average Latency: {metrics_df['latency_ms'].mean():.2f} ms")
    print(f"Accuracy: {tracking_success_rate:.2f}%")
